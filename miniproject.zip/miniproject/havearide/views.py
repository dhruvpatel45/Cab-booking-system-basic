from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
from django.contrib import messages
from .models import reg,ulogin,dlogin,driver,homedata,Receipt, Feedback,DHomeData,forgotpass,dforgotpass
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.utils.crypto import get_random_string
from django.conf import settings
from django.core.exceptions import ValidationError
from django.contrib.auth import authenticate, login
from django.contrib.auth.hashers import make_password,check_password


# Create your views here.
# welcome page

def welcome(request):
    return render(request,'welcome.html')

# u_reg process 

def signup(request):
    if request.method == 'POST':
        create_password = request.POST.get('create_password')
        reenter_password = request.POST.get('reenter_password')

        if create_password != reenter_password:
            response_content = "<b><h2>Passwords do not match.</h2></b>"
            response_content += '<br><br><a href="/signup/" class="btn btn-default">Go Back</a>'
            return HttpResponse(response_content)

        name = request.POST.get('name')
        address = request.POST.get('address')
        gender = request.POST.get('gender')
        number = request.POST.get('number')
        username = request.POST.get('username')
        email = request.POST.get('email')

        hashed_password = make_password(create_password)

        try:
            ValidationError(email)
        except ValidationError:
            response_content = "<b><h2>Invalid email address.</h2></b>"
            response_content += '<br><br><a href="/signup/" class="btn btn-default">Go Back</a>'
            return HttpResponse(response_content)

        rg = reg(Name=name, Address=address, Gender=gender, Mobile_Number=number, Create_Password=hashed_password, Reenter_Password=reenter_password, Username=username, Email=email)
        rg.save()

        if len(number) != 10:
            response_content = "<b><h2>Enter phone number properly.</h2></b>"
            response_content += '<br><br><a href="/signup/" class="btn btn-default">Go Back</a>'
            return HttpResponse(response_content)

        if len(create_password) != 6:
            response_content = "<b><h2>Enter password of length 6.</h2></b>"
            response_content += '<br><br><a href="/signup/" class="btn btn-default">Go Back</a>'
            return HttpResponse(response_content)

        if gender.lower() == 'male':
            print("male")
        elif gender.lower() == 'female':
            print("female")
        else:
            response_content = "<h2><b>Enter male or female.</b></h2>"
            response_content += '<br><br><a href="/signup/" class="btn btn-default">Go Back</a>'
            return HttpResponse(response_content)

        var1 = {'a': name, 'b': number}
        request.session['signup_data'] = {'name': name, 'number': number}
        return redirect('login')
    else:
        return render(request, 'reg.html')

# d_reg process

def driver_signup(request):
    if request.method == 'POST':
        
        d_name = request.POST.get('d_name')
        d_address = request.POST.get('d_address')
        d_gender = request.POST.get('d_gender')
        d_number = request.POST.get('d_number')
        v_number = request.POST.get('v_number')
        v_type = request.POST.get('v_type')
        dg=driver(d_name=d_name,d_address=d_address,d_gender=d_gender,d_number=d_number,v_number=v_number,v_type=v_type)
        dg.save()
        if len(d_number) != 10:
            return HttpResponse("<b><h2>Enter phone number properly..</h2></b><br><br>"
                                '<a href="/driver_signup/" class="btn btn-default">Go Back</a>')


        if d_gender.lower() not in ['male', 'female']:
            return HttpResponse("<h2><b>Enter male or female..</b></h2><br><br>"
                                '<a href="/driver_signup/" class="btn btn-default">Go Back</a>')    
        driver_data = {'d_name': d_name, 'd_number': d_number, 'v_number': v_number, 'v_type': v_type}
        request.session['signup_data'] = driver_data
        return redirect('dlogin')  
    else:
       
        return render(request, 'driver_signup.html')

# u_login process
    
def login(request):
    if request.method == 'POST':
        username_input = request.POST.get('username')
        passw = request.POST.get('passw')
        
        log = ulogin(username=username_input, passw=passw)
        log.save()
        if len(passw) > 6:
            response_content = "<b><h2>Password should be 6 characters or less.</h2></b>"
            response_content += '<br><br><a href="/login/" class="btn btn-default">Go Back</a>'
            return HttpResponse(response_content)

        
       
        signup_data = request.session.get('signup_data', {})
        stored_username = signup_data.get('name', '')
        stored_password = signup_data.get('password', '')

        if username_input == stored_username and passw == stored_password:
            return redirect('homepage')
        else:
            messages.error(request, 'Invalid username or password.')
            return redirect('homepage')
    else:
        return render(request, 'login.html')

# u_forgotpassword process

def forgot_password(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        passw = request.POST.get('passw')

        newpass=forgotpass(username= username,newpassw=passw)
        newpass.save()   

        if len(passw) > 6:
            response_content = "<b><h2>Password should be 6 characters or less.</h2></b>"
            response_content += '<br><br><a href="/forgot_password/" class="btn btn-default">Go Back</a>'
            return HttpResponse(response_content)

    
        return redirect('login')

    return render(request, 'forgot_password.html')

# d_login process

def driverlogin(request):
    if request.method == 'POST':
        username_input = request.POST.get('username')
        passw = request.POST.get('passw')
        
        log=dlogin(username= username_input,passw=passw)
        log.save()
        if len(passw) > 6:
            response_content = "<b><h2>Password should be 6 characters or less.</h2></b>"
            response_content += '<br><br><a href="/dlogin/" class="btn btn-default">Go Back</a>'
            return HttpResponse(response_content)
        signup_data = request.session.get('signup_data', {})
        stored_username = signup_data.get('name', '')
        stored_password = signup_data.get('password', '')

      
        if username_input == stored_username and passw == stored_password:
          
            return redirect('dhome')
        else:
          
            messages.error(request, 'Invalid username or password.')
        return redirect('dhome')
    else:
        return render(request, 'dlogin.html')

# d_forgotpassword process

def dforgot_password(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        passw = request.POST.get('passw')

        newpass=dforgotpass(username= username,newpassw=passw)
        newpass.save() 
        if len(passw) > 6:
            response_content = "<b><h2>Password should be 6 characters or less.</h2></b>"
            response_content += '<br><br><a href="/dforgot_password/" class="btn btn-default">Go Back</a>'
            return HttpResponse(response_content)

    
        return redirect('dlogin')

    return render(request, 'dforgot_password.html')    

# u_homepage
        
def homepage(request):
        if request.method=='POST':
               pickup_location=request.POST.get('pickup_location')
               intermediate_location=request.POST.get('intermediate_location')
               drop_location=request.POST.get('drop_location')
               city=request.POST.get('city')
               driver=request.POST.get('driver')
               state=request.POST.get('state')
               cab_type=request.POST.get('cab_type')
               two_wheeler=request.POST.get('two_wheeler')
               four_wheeler=request.POST.get('four_wheeler')
               with_driver=request.POST.get('with_driver')
               without_driver=request.POST.get('without_driver')
               
               home=homedata(pickup_location=pickup_location, intermediate_location=intermediate_location, drop_location=drop_location, city=city, state=state)
               home.save()

               if cab_type==two_wheeler:
                    print('TWO-WHEELER')
               else:
                    print('FOUR WHEELER')

               if driver==with_driver:
                    print('WITH_DRIVER')
               else:
                    print('WITHOUT_DRIVER')
              
             
               var2={'v1':pickup_location,'v2':drop_location,'v3':cab_type,'v4':driver}
               request.session['homepage_data'] = {'pickup_location': pickup_location, 'drop_location': drop_location,'intermediate_location':intermediate_location,'driver':driver,'cab_type':cab_type}
               return redirect('booking')
        reg_var = request.session.get('signup_data', {})
            
        return render (request,'homepage.html',{
        'reg_var': reg_var})

# d_homepage

def dhome(request):
    reg_var = request.session.get('signup_data', {})
    home_var = request.session.get('homepage_data', {})

    if request.method == 'POST':
        accept = request.POST.get('accept')
        rejection = request.POST.get('rejection')

        if accept:
            acceptance_status = 'accept'
        elif rejection:
            acceptance_status = 'reject'
        else:
            acceptance_status = 'unknown'

        dhome_data = DHomeData(acceptance_status=acceptance_status)
        dhome_data.save()

        request.session['choice'] = acceptance_status
        return redirect('dar')

    return render(request, 'dhome.html', {
        'reg_var': reg_var,
        'home_var': home_var,
    })

# d_choice

def dar(request):
    choice = request.session.get('choice', '')
    dar_var = {'ride': choice}  

    return render(request, 'dar.html', {'dar_var': dar_var})

# booking data

def booking(request):
    if request.method == 'POST':
        
     
        payment_method = request.POST.get('payment_method')
        

        homepage_data = request.session.get('homepage_data', {})
        pickup_location = homepage_data.get('pickup_location', '')
        intermediate_location=homepage_data.get('intermediate_location','')
        drop_location = homepage_data.get('drop_location','')
        if payment_method in [ 'cash']:
            return redirect('recipt')
        else:
            return HttpResponse("Invalid payment method. Please choose 'credit_card', 'cash', or 'upi'.")

    else:
        return render(request, 'booking.html')

# calculate cost
    
def calculate_trip_cost(distance, rate_per_km):
    """
    Calculate the total cost of the trip based on distance and rate per kilometer.
    """
    return distance * rate_per_km

# bill

def recipt(request):
    reg_var = request.session.get('signup_data', {})
    home_var = request.session.get('homepage_data', {})

    if not reg_var or not home_var:
        return HttpResponse("Invalid data. Please complete the required steps.")
    
    payment_method = request.POST.get('payment_method')
        
    homepage_data = request.session.get('homepage_data', {})
    pickup_location = homepage_data.get('pickup_location', '')
    intermediate_location=homepage_data.get('intermediate_location','')
    drop_location = homepage_data.get('drop_location','')
    distance = float(request.POST.get('distance', 0))
    rate_per_km = 25
    total_amount = calculate_trip_cost(distance, rate_per_km)

    receipt = Receipt(  
        payment_method=payment_method,
        intermediate_location=intermediate_location,
        drop_location=drop_location,
        pickup_location=pickup_location,  
        distance=distance,
        rate_per_km=rate_per_km,
        total_amount=total_amount
    )
    receipt.save()

    book_var = {
        'distance': distance,
        'rate_per_km': rate_per_km,
        'total_amount': total_amount,
    }

    return render(request, 'recipt.html', {
        'reg_var': reg_var,
        'home_var': home_var,
        'book_var': book_var,
    })

# feedback

def feedback(request):
    if request.method == 'POST':
        user_name = request.POST.get('user_name')
        comment = request.POST.get('comment')

        feedback_instance = Feedback(user_name=user_name, comment=comment)
        feedback_instance.save()

        return redirect ('thank_you')

    return render(request, 'feedback.html')

# thankyou

def thank_you(request):
       
    return render(request, 'thank_you.html')

# logout

def logout(request):
     return redirect(welcome)
      