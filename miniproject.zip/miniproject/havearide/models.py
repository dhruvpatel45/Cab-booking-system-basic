from djongo import models 

#for u_reg table

class reg(models.Model):
    Name = models.CharField(max_length=20, null=False)
    Username = models.CharField(max_length=50, unique=True)
    Email = models.EmailField(unique=True)
    Address = models.CharField(max_length=100)
    Gender = models.CharField(max_length=20)
    Mobile_Number = models.CharField(max_length=20)
    Create_Password = models.CharField(max_length=6)
    Reenter_Password = models.CharField(max_length=6)
    class Meta:
        db_table="reg"

#for u_log table

class ulogin(models.Model):
    username = models.CharField(max_length=15, null=False)
    passw = models.CharField(max_length=50)
    class Meta:
        db_table ="ulogin"

#for u_forgotpass table

class forgotpass(models.Model):
    username = models.CharField(max_length=15, null=False)
    newpassw = models.CharField(max_length=6)
    class Meta:
        db_table ="userforgotpass"

#for d_reg table

class driver(models.Model):
    d_name = models.CharField(max_length=20, null=False)
    d_address = models.CharField(max_length=100)
    d_gender = models.CharField(max_length=20)
    d_number = models.CharField(max_length=10)
    v_number = models.CharField(max_length=10)
    v_type = models.CharField(max_length=50)
    class Meta:
        db_table="driver"

#for d_login table

class dlogin(models.Model):
    username = models.CharField(max_length=15, null=False)
    passw = models.CharField(max_length=50)
    class Meta:
        db_table ="dlogin"

#for d_passreset table

class dforgotpass(models.Model):
    username = models.CharField(max_length=15, null=False)
    newpassw = models.CharField(max_length=6)
    class Meta:
        db_table ="driverforgotpass"

#for u_home table

class homedata(models.Model):
    pickup_location = models.CharField(max_length=100)
    intermediate_location = models.CharField(max_length=100)
    drop_location = models.CharField(max_length=100)
    city = models.CharField(max_length=20)
    state = models.CharField(max_length=20)
    class Meta:
         db_table="homedata"

#for bill table

class Receipt(models.Model):
    payment_method = models.CharField(max_length=100)
    pickup_location = models.CharField(max_length=100)
    intermediate_location = models.CharField(max_length=100)
    drop_location = models.CharField(max_length=100)
    distance = models.FloatField()
    rate_per_km = models.FloatField()
    total_amount = models.FloatField()
    class Meta:
        db_table="receipt"

#for feedback table

class Feedback(models.Model):
    user_name = models.CharField(max_length=100)
    comment = models.TextField()
    class Meta:
        db_table="feedback"

#for d_home table

class DHomeData(models.Model):
    acceptance_status = models.CharField(max_length=10)
    class Meta:
        db_table="driver_home"

def __str__(self):
        return self.d_name