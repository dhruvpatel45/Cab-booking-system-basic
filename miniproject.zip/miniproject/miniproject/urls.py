"""
URL configuration for miniproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from havearide import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.welcome,name='welcome'),
    path('reg/', views.signup,name='signup'),
    path('signup/', views.signup, name='signup'),
    path('driverreg/', views.driver_signup,name='driver_signup'),
    path('driver_signup/', views.driver_signup, name='driver_signup'),
    path('dlogin/',views.driverlogin,name='dlogin'),
    path('login/',views.login,name='login'),
    path('login/home.html', views.homepage, name='homepage'),
    path('forgot_password/', views.forgot_password, name='forgot_password'),
    path('dforgot_password/', views.dforgot_password, name='dforgot_password'),
    path('homepage/', views.homepage,name='homepage'),
    path('dhome/', views.dhome,name='dhome'),
    path('dar/',views.dar,name='dar'),
    path('booking/', views.booking,name='booking'),
    path('recipt/', views.recipt,name='recipt'),
    path('feedback/', views.feedback,name='feedback'),
    path('thank_you/', views.thank_you,name='thank_you'),
     path('logout/', views.logout, name='logout'),
     
]